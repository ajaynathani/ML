Launching the app
-	Sava all the files a folder
-	pip install -r requirements.txt 
-	Run command ‘python app.py’
-	Navigate to http://localhost:5000/

Site is also deployed at: http://ai4goodcyan.pythonanywhere.com/
